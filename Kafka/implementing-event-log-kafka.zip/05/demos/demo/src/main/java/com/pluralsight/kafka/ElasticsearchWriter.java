package com.pluralsight.kafka;

import io.confluent.kafka.serializers.KafkaJsonDeserializer;
import io.confluent.kafka.serializers.KafkaJsonDeserializerConfig;
import io.confluent.kafka.serializers.KafkaJsonSerializer;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

public class ElasticsearchWriter {
    public static void main(String[] args) {

        Properties props = new Properties();

        props.put("bootstrap.servers", "pkc-e8mp5.eu-west-1.aws.confluent.cloud:9092");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.jaas.config",
                "org.apache.kafka.common.security.plain.PlainLoginModule   required username=\"GSXOH3AQK3PYTUML\"  " +
                        " password=\"a35AnGs+6bgYJMHxqoIOPBMRx4TqlukNDNm9NtXqMSYcMEwCqVjeolwfvoO8SwlG\";");
        props.put("ssl.endpoint.identification.algorithm", "https");
        props.put("sasl.mechanism", "PLAIN");

        props.put("auto.offset.reset", "earliest");
        props.put("application.id", "elasticsearch-writer");


        var topology = createTopology();

        KafkaStreams streams = new KafkaStreams(topology, props);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> streams.close()));
        streams.start();
    }

    private static Topology createTopology() {
        RestHighLevelClient client = getElasticsearchClient();

        StreamsBuilder builder = new StreamsBuilder();
        builder
                .stream("typed-job-postings", Consumed.with(
                        Serdes.String(),
                        createValuesSerde(JobPostingWithType.class)))
                .foreach((k, v) -> {
                    System.out.println(k + " -> " + v);
                    writeRecordToElasticsearch(client, v);
                });
        return builder.build();
    }

    private static RestHighLevelClient getElasticsearchClient() {

        final CredentialsProvider credentialsProvider =
                new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials("elastic", "UwC13zJNcac202FltcAXMpVs"));

        RestClientBuilder builder = RestClient.builder(
                new HttpHost(
                        "10472187aad048e6997ffc41cb9a1fa9.eu-west-1.aws.found.io", 9243, "https"
                ))
                .setHttpClientConfigCallback(httpClientBuilder -> httpClientBuilder
                        .setDefaultCredentialsProvider(credentialsProvider));

        return new RestHighLevelClient(builder);
    }

    private static void writeRecordToElasticsearch(RestHighLevelClient client, JobPostingWithType jobPostingWithType) {

        try {
            XContentBuilder builder = XContentFactory.jsonBuilder()
                    .startObject()
                    .field("userId", jobPostingWithType.getUserId())
                    .field("jobTitle", jobPostingWithType.getJobTitle())
                    .field("jobDescription", jobPostingWithType.getJobDescription())
                    .field("salary", jobPostingWithType.getSalary())
                    .field("type", jobPostingWithType.getType())
                    .endObject();

            IndexRequest indexRequest = new IndexRequest("job-postings");
            indexRequest.source(builder);
            client.index(indexRequest, RequestOptions.DEFAULT);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static <T> Serde<T> createValuesSerde(Class<T> valueType) {
        var serializer = new KafkaJsonSerializer<T>();
        serializer.configure(Map.of(), false);

        var deseriazlier = new KafkaJsonDeserializer<T>();
        deseriazlier.configure(Map.of(
                KafkaJsonDeserializerConfig.JSON_VALUE_TYPE, valueType.getName()
        ), false);

        return Serdes.serdeFrom(serializer, deseriazlier);
    }
}
