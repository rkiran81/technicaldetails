package com.pluralsight.kafka;

public class UserBlocked {
    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "UserBlocked{" +
                "userId='" + userId + '\'' +
                '}';
    }
}
