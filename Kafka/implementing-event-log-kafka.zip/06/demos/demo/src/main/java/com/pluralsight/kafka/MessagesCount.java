package com.pluralsight.kafka;

import java.util.Date;

public class MessagesCount {
    private String userId;
    private long count;
    private Date timestamp;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "MessagesCount{" +
                "userId='" + userId + '\'' +
                ", count=" + count +
                ", timestamp=" + timestamp +
                '}';
    }
}
