package com.pluralsight.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Date;
import java.util.Properties;

public class MessageGenerator {

    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        props.put("bootstrap.servers", "pkc-e8mp5.eu-west-1.aws.confluent.cloud:9092");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.jaas.config",
                "org.apache.kafka.common.security.plain.PlainLoginModule   required username=\"GSXOH3AQK3PYTUML\"  " +
                        " password=\"a35AnGs+6bgYJMHxqoIOPBMRx4TqlukNDNm9NtXqMSYcMEwCqVjeolwfvoO8SwlG\";");
        props.put("ssl.endpoint.identification.algorithm", "https");
        props.put("sasl.mechanism", "PLAIN");
        props.put("retries", 3);

        Producer<String, String> producer = new KafkaProducer<>(props, new StringSerializer(), new StringSerializer());

        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            MessagePosted messagePosted = generateUserMessage();
            String pageViewStr = toJsonString(messagePosted);
            System.out.println(messagePosted);

            RecordMetadata metadata = producer
                    .send(new ProducerRecord<>("message-posted", messagePosted.getUserId(), pageViewStr))
                    .get();

            System.out.println(String.format("Key = %s; partition = %s; offset = %s",
                    messagePosted.getUserId(),
                    metadata.partition(),
                    metadata.offset()));
            System.out.println();
        }

        producer.flush();
        producer.close();
    }

    private static String toJsonString(MessagePosted messagePosted) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(messagePosted);
    }

    private static MessagePosted generateUserMessage() {

        Faker faker = new Faker();

        MessagePosted messagePosted = new MessagePosted();

        messagePosted.setUserId(faker.number().digits(2));
        messagePosted.setMessage(faker.lorem().characters(10, 20));
        messagePosted.setCreatedAt(new Date());

        return messagePosted;
    }
}
